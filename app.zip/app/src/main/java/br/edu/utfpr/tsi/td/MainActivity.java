package br.edu.utfpr.tsi.td;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    final static int TELA_VEICULOS = 123;
    private LinkedList<Veiculo> veiculos;
    ArrayAdapter<Veiculo> adapter;
    ListView lista;
    int posicaoEdicao = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        veiculos = new LinkedList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, veiculos);

        lista = (ListView) findViewById(R.id.lista_interessados);
        lista.setAdapter(adapter);
        lista.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                posicaoEdicao = position;
                Intent it = new Intent(MainActivity.this, TelaVeiculos.class);
                it.putExtra("veiculosEdicao", veiculos.get(position));
                startActivityForResult(it, TELA_VEICULOS);
                return true;
            }
        });
    }

    public void adicionar(View view){
        Intent it = new Intent(this, TelaVeiculos.class);
        startActivityForResult(it, TELA_VEICULOS);
    }


    public void remover(View view) {
        final int pos = lista.getCheckedItemPosition();
        if (pos == 1) {
            Toast.makeText(this, "Selecione o Veiculo", Toast.LENGTH_SHORT).show();
        } else {
            AlertDialog.Builder bld = new AlertDialog.Builder(this);
            bld.setTitle("Confirmação");
            bld.setMessage("Deseja realmente remover este veiculo?");
            bld.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    veiculos.remove(pos);
                    adapter.notifyDataSetChanged();
                }
            });
            bld.setNegativeButton("Não", null);
            bld.show();
        }
    }

    public void atualizar(View view) {
        final int pos = lista.getCheckedItemPosition();
        if (pos >= 0) {
            Veiculo veiculoParaAtualizar = veiculos.get(pos);
            Intent it = new Intent(this, TelaVeiculos.class);
            it.putExtra("veiculosEdicao", veiculoParaAtualizar);
            startActivityForResult(it, TELA_VEICULOS);
        } else {
            Toast.makeText(this, "Selecione um veículo para editar.", Toast.LENGTH_SHORT).show();
        }
    }

    public void buscar(View view) {
        EditText editTextBusca = findViewById(R.id.busca_Interessado);

        String termoBusca = editTextBusca.getText().toString().toLowerCase();

        List<Veiculo> resultadosBusca = new ArrayList<>();

        for (Veiculo veiculo : veiculos) {
            String modelo = veiculo.getModelo().toLowerCase();
            String marca = veiculo.getMarca().toLowerCase();
            double valor = veiculo.getValor();

            if (modelo.contains(termoBusca) || marca.contains(termoBusca)) {
                resultadosBusca.add(veiculo);
            }

            if (termoBusca.contains("até")) {
                String[] partes = termoBusca.split("até");
                if (partes.length == 2) {
                    String valorMaximoStr = partes[1].trim();
                    try {
                        double valorMaximo = Double.parseDouble(valorMaximoStr);
                        if (valor <= valorMaximo) {
                            resultadosBusca.add(veiculo);
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }
            else if (modelo.contains(termoBusca)) {
                resultadosBusca.add(veiculo);
            }else if (marca.contains(termoBusca)) {
                resultadosBusca.add(veiculo);
            }

        }

        ArrayAdapter<Veiculo> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, resultadosBusca);
        lista.setAdapter(adapter);

        lista.clearChoices();
    }

    @Override
    public void onActivityResult(int codigo, int resultado, Intent dados){
        super.onActivityResult(codigo,resultado, dados);
        if (codigo == TELA_VEICULOS && resultado == RESULT_OK){
            Veiculo in = (Veiculo) dados.getSerializableExtra("veiculos");
            if (posicaoEdicao >= 0){
                veiculos.set(posicaoEdicao, in);
            }else {
                veiculos.add(in);
            }
            adapter.notifyDataSetChanged();
        }
    }
}
