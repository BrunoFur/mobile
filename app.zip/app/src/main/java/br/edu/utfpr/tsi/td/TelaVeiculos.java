package br.edu.utfpr.tsi.td;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class TelaVeiculos extends AppCompatActivity {

    EditText ed_nomeContVeic, ed_emailContVeic, ed_telContVeic, ed_Modelo, ed_Marca, ed_anoFab, ed_valor;
    Spinner ed_tpVeiculo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_veiculos);
        ed_nomeContVeic = (EditText) findViewById(R.id.ed_nomeContVeic);
        ed_emailContVeic = (EditText) findViewById(R.id.ed_emailContVeic);
        ed_telContVeic = (EditText) findViewById(R.id.ed_telContVeic);
        ed_tpVeiculo = (Spinner) findViewById(R.id.ed_tpVeiculo);
        ed_Marca = (EditText) findViewById(R.id.ed_Marca);
        ed_Modelo = (EditText) findViewById(R.id.ed_Modelo);
        ed_anoFab = (EditText) findViewById(R.id.ed_anoFab);
        ed_valor = (EditText) findViewById(R.id.ed_valor);
        String[] tiposVeiculo = {"Moto", "Automóvel", "Caminhão"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tiposVeiculo);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ed_tpVeiculo.setAdapter(adapter);

        Veiculo i = (Veiculo) getIntent().getSerializableExtra("veiculosEdicao");

        if (i != null){
            ed_nomeContVeic.setText(i.getNome());
            ed_emailContVeic.setText(i.getEmail());
            ed_telContVeic.setText(i.getTelefone());
            int posicaoSelecionada = -1;
            for (int j = 0; j < tiposVeiculo.length; j++) {
                if (tiposVeiculo[j].equals(i.getTipoVeiculo())) {
                    posicaoSelecionada = j;
                    break;
                }
            }
            if (posicaoSelecionada != -1) {
                ed_tpVeiculo.setSelection(posicaoSelecionada);
            }
            ed_Marca.setText(i.getMarca());
            ed_Modelo.setText(i.getModelo());
            ed_anoFab.setText((String.valueOf(i.getAno())));
            ed_valor.setText(String.valueOf(i.getValor()));
        }
    }

    public void confirmar(View view){
        String nome = ed_nomeContVeic.getText().toString();
        String email = ed_emailContVeic.getText().toString();
        String telefone = ed_telContVeic.getText().toString();
        String tipoVeiculo = ed_tpVeiculo.getSelectedItem().toString();
        String marca = ed_Marca.getText().toString();
        String modelo = ed_Modelo.getText().toString();
        String anoFabricacao = ed_anoFab.getText().toString();
        String valor = ed_valor.getText().toString();
        Veiculo i =  new Veiculo();
        i.setNome(nome);
        i.setEmail(email);
        i.setTelefone(telefone);
        i.setTipoVeiculo(tipoVeiculo);
        i.setMarca(marca);
        i.setModelo(modelo);
        i.setAno(Integer.parseInt(anoFabricacao));
        i.setValor(Double.parseDouble(valor));

        Intent dados = new Intent();
        dados.putExtra("veiculos", i);
        setResult(RESULT_OK, dados);
        finish();
    }
}
